#!/bin/sh
rm -rf *.csv
rm -rf *.out
